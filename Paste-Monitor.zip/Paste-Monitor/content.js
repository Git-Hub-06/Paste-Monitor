// ─── Shared pattern registry ────────────────────────────────────────────────
const SECRET_PATTERNS = [

    // ── API Keys & Tokens ──────────────────────────────────────────────────
    { regex: /sk-[a-zA-Z0-9]{10,}/g,                          mask: "sk-****",       label: "OpenAI API Key"        },
    { regex: /AKIA[0-9A-Z]{10,}/g,                            mask: "AWS-****",      label: "AWS Access Key"        },
    { regex: /ghp_[a-zA-Z0-9]{10,}/g,                         mask: "ghp_****",      label: "GitHub Personal Token" },
    { regex: /AIza[0-9A-Za-z_-]{35}/g,                        mask: "AIza-****",     label: "Google API Key"        },
    { regex: /Bearer\s[a-zA-Z0-9\-._~+/]{20,}/g,              mask: "Bearer ****",   label: "Bearer Token"          },

    // ── Email Addresses ────────────────────────────────────────────────────
    // Matches standard email format: user@domain.tld
    {
        regex: /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g,
        mask: "****@****.***",
        label: "Email Address"
    },

    // ── Username / Password patterns ───────────────────────────────────────
    // Matches: username=value, user=value, login=value (case-insensitive)
    {
        regex: /(?:username|user|login|uname)\s*[=:]\s*\S+/gi,
        mask: "username=****",
        label: "Username"
    },
    // Matches: password=value, passwd=value, pwd=value, pass=value
    {
        regex: /(?:password|passwd|pwd|pass)\s*[=:]\s*\S+/gi,
        mask: "password=****",
        label: "Password"
    },
    // Matches connection strings: user:password@host format
    {
        regex: /[a-zA-Z0-9._\-]+:[a-zA-Z0-9!@#$%^&*()_+\-=]{4,}@[a-zA-Z0-9.\-]+/g,
        mask: "****:****@****",
        label: "Credential String"
    },

    // ── IP Addresses ───────────────────────────────────────────────────────
    // IPv4: 0.0.0.0 – 255.255.255.255
    {
        regex: /\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b/g,
        mask: "[IP-HIDDEN]",
        label: "IPv4 Address"
    },
    // IPv6: full and compressed forms
    {
        regex: /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b/g,
        mask: "[IPv6-HIDDEN]",
        label: "IPv6 Address"
    },

    // ── Hostnames / Internal FQDNs ─────────────────────────────────────────
    // Matches internal hostnames: server01, dc01.corp.local, host.internal
    // Anchored to avoid matching common public domains like google.com
    {
        regex: /\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+(?:local|internal|intranet|corp|lan|home|private|test|dev|staging|prod|localhost)\b/gi,
        mask: "[HOST-HIDDEN]",
        label: "Internal Hostname"
    },
    // Bare hostnames: single-label names like WKSTN01, SRV-DC01 (all-caps or mixed with digits/dashes, no dots)
    {
        regex: /\b[A-Z][A-Z0-9\-]{3,}(?:\.[A-Z][A-Z0-9\-]{2,})*\b(?!\.[a-z]{2,})/g,
        mask: "[HOST-HIDDEN]",
        label: "Internal Hostname"
    },
];

// ─── Detect which patterns matched ──────────────────────────────────────────
function detectPatterns(text) {
    return SECRET_PATTERNS
        .filter(p => { p.regex.lastIndex = 0; return p.regex.test(text); })
        .map(p => p.label);
}

// ─── Mask all matching patterns ──────────────────────────────────────────────
function maskSecrets(text) {
    let result = text;
    SECRET_PATTERNS.forEach(({ regex, mask }) => {
        regex.lastIndex = 0;
        result = result.replace(regex, mask);
    });
    return result;
}

// ─── Insert text into whatever element is focused ───────────────────────────
function insertText(text) {
    const el = document.activeElement;
    if (!el) return;

    if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
        const start = el.selectionStart ?? el.value.length;
        const end   = el.selectionEnd   ?? el.value.length;
        el.value = el.value.slice(0, start) + text + el.value.slice(end);
        el.selectionStart = el.selectionEnd = start + text.length;
        el.dispatchEvent(new Event("input", { bubbles: true }));
    } else if (el.isContentEditable) {
        // execCommand is deprecated but still the most compatible approach
        // for contentEditable (Gmail, Notion, etc.)
        document.execCommand("insertText", false, text);
    }
}

// ─── Show an in-page banner alert (non-blocking, auto-dismisses) ─────────────
function showAlert(matchedLabels) {
    // Remove any existing banner
    document.getElementById("__paste-monitor-alert__")?.remove();

    const banner = document.createElement("div");
    banner.id = "__paste-monitor-alert__";
    banner.style.cssText = `
        position: fixed;
        top: 18px;
        right: 18px;
        z-index: 2147483647;
        background: #ffffff;
        color: #101828;
        border: 1px solid #fecdca;
        border-left: 4px solid #d92d20;
        border-radius: 8px;
        padding: 13px 16px;
        font-family: 'Inter', -apple-system, sans-serif;
        font-size: 13px;
        max-width: 320px;
        box-shadow: 0 4px 24px rgba(16,24,40,0.15);
        animation: __pm_slidein__ 0.22s ease;
        cursor: pointer;
    `;

    const style = document.createElement("style");
    style.textContent = `
        @keyframes __pm_slidein__ {
            from { opacity: 0; transform: translateY(-12px); }
            to   { opacity: 1; transform: translateY(0);     }
        }
    `;
    document.head.appendChild(style);

    banner.innerHTML = `
        <div style="font-weight:600; color:#d92d20; margin-bottom:5px; font-size:13px;">⚠ Sensitive Data Masked</div>
        <div style="color:#b54708; font-size:12px; font-weight:500;">Detected: ${matchedLabels.join(", ")}</div>
        <div style="color:#667085; font-size:11px; margin-top:5px;">Content was sanitized before pasting.</div>
    `;

    // Close on click
    banner.addEventListener("click", () => banner.remove());
    document.body.appendChild(banner);

    // Auto-dismiss after 5 s
    setTimeout(() => banner?.remove(), 5000);
}

// ─── Paste listener (capture phase so we run first) ─────────────────────────
document.addEventListener("paste", (e) => {
    const text = e.clipboardData.getData("text");
    if (!text) return;

    const matched = detectPatterns(text);
    const isSensitive = matched.length > 0;
    const finalText = isSensitive ? maskSecrets(text) : text;

    if (isSensitive) {
        e.preventDefault();         // block original paste
        insertText(finalText);      // insert masked version
        showAlert(matched);         // in-page banner
        console.warn("[PasteMonitor] Sensitive data masked:", matched.join(", "));
    }

    // Always log to history (masked if sensitive)
    chrome.runtime.sendMessage({
        type: "PASTE_EVENT",
        payload: {
            text:       finalText,
            url:        location.href,
            masked:     isSensitive,
            detections: matched,
            ts:         Date.now(),
        },
    });
}, true /* capture: true — ensures we fire before page scripts */);