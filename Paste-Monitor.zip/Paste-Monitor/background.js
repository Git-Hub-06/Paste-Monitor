chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "PASTE_EVENT") {
        chrome.storage.local.get(["history"], (result) => {
            const history = result.history || [];

            history.unshift(msg.payload);   // newest first

            // Keep max 100 entries
            if (history.length > 100) history.pop();

            chrome.storage.local.set({ history });
        });
    }
});