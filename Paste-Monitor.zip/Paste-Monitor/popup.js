// ─── Unified patterns (must match content.js exactly) ───────────────────────
const SECRET_PATTERNS = [

    // ── API Keys & Tokens ──────────────────────────────────────────────────
    { regex: /sk-[a-zA-Z0-9]{10,}/g,                          mask: "sk-****",       label: "OpenAI API Key"        },
    { regex: /AKIA[0-9A-Z]{10,}/g,                            mask: "AWS-****",      label: "AWS Access Key"        },
    { regex: /ghp_[a-zA-Z0-9]{10,}/g,                         mask: "ghp_****",      label: "GitHub Personal Token" },
    { regex: /AIza[0-9A-Za-z_-]{35}/g,                        mask: "AIza-****",     label: "Google API Key"        },
    { regex: /Bearer\s[a-zA-Z0-9\-._~+/]{20,}/g,              mask: "Bearer ****",   label: "Bearer Token"          },

    // ── Email Addresses ────────────────────────────────────────────────────
    {
        regex: /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g,
        mask: "****@****.***",
        label: "Email Address"
    },

    // ── Username / Password patterns ───────────────────────────────────────
    {
        regex: /(?:username|user|login|uname)\s*[=:]\s*\S+/gi,
        mask: "username=****",
        label: "Username"
    },
    {
        regex: /(?:password|passwd|pwd|pass)\s*[=:]\s*\S+/gi,
        mask: "password=****",
        label: "Password"
    },
    {
        regex: /[a-zA-Z0-9._\-]+:[a-zA-Z0-9!@#$%^&*()_+\-=]{4,}@[a-zA-Z0-9.\-]+/g,
        mask: "****:****@****",
        label: "Credential String"
    },

    // ── IP Addresses ───────────────────────────────────────────────────────
    {
        regex: /\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b/g,
        mask: "[IP-HIDDEN]",
        label: "IPv4 Address"
    },
    {
        regex: /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b/g,
        mask: "[IPv6-HIDDEN]",
        label: "IPv6 Address"
    },

    // ── Hostnames / Internal FQDNs ─────────────────────────────────────────
    {
        regex: /\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+(?:local|internal|intranet|corp|lan|home|private|test|dev|staging|prod|localhost)\b/gi,
        mask: "[HOST-HIDDEN]",
        label: "Internal Hostname"
    },
    {
        regex: /\b[A-Z][A-Z0-9\-]{3,}(?:\.[A-Z][A-Z0-9\-]{2,})*\b(?!\.[a-z]{2,})/g,
        mask: "[HOST-HIDDEN]",
        label: "Internal Hostname"
    },
];

function maskSensitive(text) {
    let result = text;
    SECRET_PATTERNS.forEach(({ regex, mask }) => {
        regex.lastIndex = 0;
        result = result.replace(regex, mask);
    });
    return result;
}

function formatTime(ts) {
    if (!ts) return "";
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function truncateUrl(url) {
    try {
        const u = new URL(url);
        return u.hostname + (u.pathname.length > 1 ? u.pathname.slice(0, 24) + "…" : "");
    } catch { return url.slice(0, 32); }
}

function render(history) {
    const list     = document.getElementById("list");
    const total    = history.length;
    const masked   = history.filter(i => i.masked).length;

    // Update stats
    document.getElementById("stat-total").textContent  = total;
    document.getElementById("stat-masked").textContent = masked;
    document.getElementById("stat-clean").textContent  = total - masked;

    list.innerHTML = "";

    if (total === 0) {
        const empty = document.createElement("div");
        empty.className = "empty";
        const icon = document.createElement("div");
        icon.className = "empty-icon";
        icon.textContent = "📋";
        const msg = document.createElement("div");
        msg.textContent = "No paste events recorded yet.";
        empty.appendChild(icon);
        empty.appendChild(msg);
        list.appendChild(empty);
        return;
    }

    history.forEach(item => {
        const safeText = maskSensitive(item.text || "");

        const div = document.createElement("div");
        div.className = "item";

        // ── Top row: text + badge ──
        const top = document.createElement("div");
        top.className = "item-top";

        const textEl = document.createElement("div");
        textEl.className = "item-text";
        textEl.textContent = safeText.length > 120
            ? safeText.slice(0, 120) + "…"
            : safeText;

        const badge = document.createElement("span");
        badge.className = item.masked ? "badge badge-alert" : "badge badge-ok";
        badge.textContent = item.masked ? "⚠ masked" : "✓ clean";

        top.appendChild(textEl);
        top.appendChild(badge);

        // ── Meta row: url + time ──
        const meta = document.createElement("div");
        meta.className = "item-meta";

        const urlEl = document.createElement("div");
        urlEl.className = "item-url";
        urlEl.textContent = truncateUrl(item.url || "");
        urlEl.title = item.url || "";

        const timeEl = document.createElement("div");
        timeEl.className = "item-time";
        timeEl.textContent = formatTime(item.ts);

        meta.appendChild(urlEl);
        meta.appendChild(timeEl);

        div.appendChild(top);
        div.appendChild(meta);

        // ── Detection tags (if masked) ──
        if (item.masked && Array.isArray(item.detections) && item.detections.length) {
            const tags = document.createElement("div");
            tags.className = "detection-tags";
            item.detections.forEach(label => {
                const tag = document.createElement("span");
                tag.className = "dtag";
                tag.textContent = label;
                tags.appendChild(tag);
            });
            div.appendChild(tags);
        }

        list.appendChild(div);
    });
}

// ─── Load & render ───────────────────────────────────────────────────────────
chrome.storage.local.get(["history"], (result) => {
    render(result.history || []);
});

// ─── Clear history ───────────────────────────────────────────────────────────
document.getElementById("clear-btn").addEventListener("click", () => {
    chrome.storage.local.set({ history: [] }, () => render([]));
});