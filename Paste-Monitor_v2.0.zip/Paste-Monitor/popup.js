// ─── Unified patterns (must match content.js exactly) ───────────────────────
const SECRET_PATTERNS = [
    { regex: /sk-[a-zA-Z0-9]{10,}/g,                          mask: "sk-****",       label: "OpenAI API Key"        },
    { regex: /AKIA[0-9A-Z]{10,}/g,                            mask: "AWS-****",      label: "AWS Access Key"        },
    { regex: /ghp_[a-zA-Z0-9]{10,}/g,                         mask: "ghp_****",      label: "GitHub Personal Token" },
    { regex: /AIza[0-9A-Za-z_-]{35}/g,                        mask: "AIza-****",     label: "Google API Key"        },
    { regex: /Bearer\s[a-zA-Z0-9\-._~+/]{20,}/g,              mask: "Bearer ****",   label: "Bearer Token"          },
    { regex: /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g, mask: "****@****.***", label: "Email Address" },
    { regex: /(?:username|user|login|uname)\s*[=:]\s*\S+/gi,  mask: "username=****", label: "Username"              },
    { regex: /(?:password|passwd|pwd|pass)\s*[=:]\s*\S+/gi,   mask: "password=****", label: "Password"              },
    { regex: /[a-zA-Z0-9._\-]+:[a-zA-Z0-9!@#$%^&*()_+\-=]{4,}@[a-zA-Z0-9.\-]+/g, mask: "****:****@****", label: "Credential String" },
    { regex: /\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b/g, mask: "[IP-HIDDEN]", label: "IPv4 Address" },
    { regex: /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b/g, mask: "[IPv6-HIDDEN]", label: "IPv6 Address" },
    { regex: /\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+(?:local|internal|intranet|corp|lan|home|private|test|dev|staging|prod|localhost)\b/gi, mask: "[HOST-HIDDEN]", label: "Internal Hostname" },
    { regex: /\b[A-Z][A-Z0-9\-]{3,}(?:\.[A-Z][A-Z0-9\-]{2,})*\b(?!\.[a-z]{2,})/g, mask: "[HOST-HIDDEN]", label: "Internal Hostname" },
];

function maskSensitive(text) {
    let result = text;
    SECRET_PATTERNS.forEach(({ regex, mask }) => {
        regex.lastIndex = 0;
        result = result.replace(regex, mask);
    });
    return result;
}

function formatTime(ts) {
    if (!ts) return "";
    return new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function truncateUrl(url) {
    try {
        const u = new URL(url);
        return u.hostname + (u.pathname.length > 1 ? u.pathname.slice(0, 24) + "…" : "");
    } catch { return url.slice(0, 32); }
}

// ─── Render paste history ────────────────────────────────────────────────────
function render(history) {
    const list   = document.getElementById("list");
    const total  = history.length;
    const masked = history.filter(i => i.masked).length;

    document.getElementById("stat-total").textContent  = total;
    document.getElementById("stat-masked").textContent = masked;
    document.getElementById("stat-clean").textContent  = total - masked;

    list.innerHTML = "";

    if (total === 0) {
        const empty = document.createElement("div");
        empty.className = "empty";
        const icon = document.createElement("div");
        icon.className = "empty-icon";
        icon.textContent = "📋";
        const msg = document.createElement("div");
        msg.textContent = "No paste events recorded yet.";
        empty.appendChild(icon);
        empty.appendChild(msg);
        list.appendChild(empty);
        return;
    }

    history.forEach(item => {
        const maskedText   = maskSensitive(item.text || "");
        const originalText = item.originalText || null;

        const div = document.createElement("div");
        div.className = "item";

        // Top row: text + badge
        const top = document.createElement("div");
        top.className = "item-top";

        const textEl = document.createElement("div");
        textEl.className = "item-text";
        textEl.textContent = maskedText.length > 120 ? maskedText.slice(0, 120) + "…" : maskedText;

        const badge = document.createElement("span");
        badge.className = item.masked ? "badge badge-alert" : "badge badge-ok";
        badge.textContent = item.masked ? "⚠ masked" : "✓ clean";

        top.appendChild(textEl);
        top.appendChild(badge);

        // Meta row: url + time
        const meta = document.createElement("div");
        meta.className = "item-meta";

        const urlEl = document.createElement("div");
        urlEl.className = "item-url";
        urlEl.textContent = truncateUrl(item.url || "");
        urlEl.title = item.url || "";

        const timeEl = document.createElement("div");
        timeEl.className = "item-time";
        timeEl.textContent = formatTime(item.ts);

        meta.appendChild(urlEl);
        meta.appendChild(timeEl);

        div.appendChild(top);
        div.appendChild(meta);

        // Detection tags + reveal + copy-original (masked items only)
        if (item.masked && Array.isArray(item.detections) && item.detections.length) {
            const footer = document.createElement("div");
            footer.className = "item-footer";

            const tags = document.createElement("div");
            tags.className = "detection-tags";
            item.detections.forEach(label => {
                const tag = document.createElement("span");
                tag.className = "dtag";
                tag.textContent = label;
                tags.appendChild(tag);
            });
            footer.appendChild(tags);

            if (originalText) {
                let revealed = false;

                const actions = document.createElement("div");
                actions.className = "item-actions";

                // ── Reveal / Hide toggle ──
                const revealBtn = document.createElement("button");
                revealBtn.className = "action-btn";
                revealBtn.title = "Reveal original text in this entry";
                revealBtn.textContent = "👁 Reveal";

                revealBtn.addEventListener("click", () => {
                    revealed = !revealed;
                    if (revealed) {
                        const full = originalText.length > 120
                            ? originalText.slice(0, 120) + "…"
                            : originalText;
                        textEl.textContent = full;
                        textEl.className   = "item-text item-text-revealed";
                        revealBtn.textContent = "🔒 Hide";
                        revealBtn.classList.add("action-btn-active");
                    } else {
                        textEl.textContent = maskedText.length > 120
                            ? maskedText.slice(0, 120) + "…"
                            : maskedText;
                        textEl.className   = "item-text";
                        revealBtn.textContent = "👁 Reveal";
                        revealBtn.classList.remove("action-btn-active");
                    }
                });

                // ── Copy original to clipboard ──
                const copyBtn = document.createElement("button");
                copyBtn.className = "action-btn";
                copyBtn.title = "Copy original unmasked text to clipboard";
                copyBtn.textContent = "📋 Copy";

                copyBtn.addEventListener("click", () => {
                    navigator.clipboard.writeText(originalText).then(() => {
                        copyBtn.textContent = "✓ Copied";
                        copyBtn.classList.add("action-btn-copied");
                        setTimeout(() => {
                            copyBtn.textContent = "📋 Copy";
                            copyBtn.classList.remove("action-btn-copied");
                        }, 2000);
                    }).catch(() => {
                        copyBtn.textContent = "✗ Failed";
                        setTimeout(() => { copyBtn.textContent = "📋 Copy"; }, 2000);
                    });
                });

                actions.appendChild(revealBtn);
                actions.appendChild(copyBtn);
                footer.appendChild(actions);
            }

            div.appendChild(footer);
        }

        list.appendChild(div);
    });
}

// ─── Render whitelist tab ─────────────────────────────────────────────────────
function renderWhitelist(whitelist) {
    const wlList = document.getElementById("wl-list");
    wlList.innerHTML = "";

    if (whitelist.length === 0) {
        const empty = document.createElement("div");
        empty.className = "empty";
        const icon = document.createElement("div");
        icon.className = "empty-icon";
        icon.textContent = "🌐";
        const msg = document.createElement("div");
        msg.textContent = "No whitelisted sites yet.";
        wlList.appendChild(icon);
        wlList.appendChild(msg);
        wlList.appendChild(empty);
        return;
    }

    whitelist.forEach(hostname => {
        const row = document.createElement("div");
        row.className = "wl-row";

        const hostEl = document.createElement("span");
        hostEl.className = "wl-host";
        hostEl.textContent = hostname;

        const removeBtn = document.createElement("button");
        removeBtn.className = "wl-remove";
        removeBtn.textContent = "✕ Remove";
        removeBtn.addEventListener("click", () => {
            chrome.storage.local.get(["whitelist"], (r) => {
                const updated = (r.whitelist || []).filter(h => h !== hostname);
                chrome.storage.local.set({ whitelist: updated }, () => renderWhitelist(updated));
            });
        });

        row.appendChild(hostEl);
        row.appendChild(removeBtn);
        wlList.appendChild(row);
    });
}

// ─── Tab switching ───────────────────────────────────────────────────────────
document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
        document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("tab-active"));
        document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("panel-active"));
        btn.classList.add("tab-active");
        document.getElementById(btn.dataset.tab).classList.add("panel-active");
    });
});

// ─── Add site to whitelist ───────────────────────────────────────────────────
document.getElementById("wl-add-btn").addEventListener("click", () => {
    const input = document.getElementById("wl-input");
    const hostname = input.value.trim().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
    if (!hostname) return;

    chrome.storage.local.get(["whitelist"], (r) => {
        const whitelist = r.whitelist || [];
        if (!whitelist.includes(hostname)) {
            whitelist.push(hostname);
            chrome.storage.local.set({ whitelist }, () => {
                renderWhitelist(whitelist);
                input.value = "";
            });
        } else {
            input.value = "";
        }
    });
});

// Allow pressing Enter in the input
document.getElementById("wl-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter") document.getElementById("wl-add-btn").click();
});

// ─── Clear history ───────────────────────────────────────────────────────────
document.getElementById("clear-btn").addEventListener("click", () => {
    chrome.storage.local.set({ history: [] }, () => render([]));
});

// ─── Initial load ────────────────────────────────────────────────────────────
chrome.storage.local.get(["history", "whitelist"], (result) => {
    render(result.history || []);
    renderWhitelist(result.whitelist || []);
});