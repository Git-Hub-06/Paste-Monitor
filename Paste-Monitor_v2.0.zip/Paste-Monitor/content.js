// ─── Shared pattern registry ────────────────────────────────────────────────
const SECRET_PATTERNS = [

    // ── API Keys & Tokens ──────────────────────────────────────────────────
    { regex: /sk-[a-zA-Z0-9]{10,}/g,                          mask: "sk-****",       label: "OpenAI API Key"        },
    { regex: /AKIA[0-9A-Z]{10,}/g,                            mask: "AWS-****",      label: "AWS Access Key"        },
    { regex: /ghp_[a-zA-Z0-9]{10,}/g,                         mask: "ghp_****",      label: "GitHub Personal Token" },
    { regex: /AIza[0-9A-Za-z_-]{35}/g,                        mask: "AIza-****",     label: "Google API Key"        },
    { regex: /Bearer\s[a-zA-Z0-9\-._~+/]{20,}/g,              mask: "Bearer ****",   label: "Bearer Token"          },

    // ── Email Addresses ────────────────────────────────────────────────────
    {
        regex: /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g,
        mask: "****@****.***",
        label: "Email Address"
    },

    // ── Username / Password patterns ───────────────────────────────────────
    {
        regex: /(?:username|user|login|uname)\s*[=:]\s*\S+/gi,
        mask: "username=****",
        label: "Username"
    },
    {
        regex: /(?:password|passwd|pwd|pass)\s*[=:]\s*\S+/gi,
        mask: "password=****",
        label: "Password"
    },
    {
        regex: /[a-zA-Z0-9._\-]+:[a-zA-Z0-9!@#$%^&*()_+\-=]{4,}@[a-zA-Z0-9.\-]+/g,
        mask: "****:****@****",
        label: "Credential String"
    },

    // ── IP Addresses ───────────────────────────────────────────────────────
    {
        regex: /\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b/g,
        mask: "[IP-HIDDEN]",
        label: "IPv4 Address"
    },
    {
        regex: /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b/g,
        mask: "[IPv6-HIDDEN]",
        label: "IPv6 Address"
    },

    // ── Hostnames / Internal FQDNs ─────────────────────────────────────────
    {
        regex: /\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+(?:local|internal|intranet|corp|lan|home|private|test|dev|staging|prod|localhost)\b/gi,
        mask: "[HOST-HIDDEN]",
        label: "Internal Hostname"
    },
    {
        regex: /\b[A-Z][A-Z0-9\-]{3,}(?:\.[A-Z][A-Z0-9\-]{2,})*\b(?!\.[a-z]{2,})/g,
        mask: "[HOST-HIDDEN]",
        label: "Internal Hostname"
    },
];

// ─── Detect which patterns matched ──────────────────────────────────────────
function detectPatterns(text) {
    return SECRET_PATTERNS
        .filter(p => { p.regex.lastIndex = 0; return p.regex.test(text); })
        .map(p => p.label);
}

// ─── Mask all matching patterns ──────────────────────────────────────────────
function maskSecrets(text) {
    let result = text;
    SECRET_PATTERNS.forEach(({ regex, mask }) => {
        regex.lastIndex = 0;
        result = result.replace(regex, mask);
    });
    return result;
}

// ─── Insert text into focused element ───────────────────────────────────────
function insertText(text) {
    const el = document.activeElement;
    if (!el) return;
    if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
        const start = el.selectionStart ?? el.value.length;
        const end   = el.selectionEnd   ?? el.value.length;
        el.value = el.value.slice(0, start) + text + el.value.slice(end);
        el.selectionStart = el.selectionEnd = start + text.length;
        el.dispatchEvent(new Event("input", { bubbles: true }));
    } else if (el.isContentEditable) {
        document.execCommand("insertText", false, text);
    }
}

// ─── In-page banner alert ────────────────────────────────────────────────────
function showAlert(matchedLabels) {
    document.getElementById("__paste-monitor-alert__")?.remove();

    const banner = document.createElement("div");
    banner.id = "__paste-monitor-alert__";
    banner.style.cssText = `
        position: fixed;
        top: 18px;
        right: 18px;
        z-index: 2147483647;
        background: #ffffff;
        color: #101828;
        border: 1px solid #fecdca;
        border-left: 4px solid #d92d20;
        border-radius: 8px;
        padding: 13px 16px;
        font-family: 'Inter', -apple-system, sans-serif;
        font-size: 13px;
        max-width: 320px;
        box-shadow: 0 4px 24px rgba(16,24,40,0.15);
        animation: __pm_slidein__ 0.22s ease;
        cursor: pointer;
    `;

    const style = document.createElement("style");
    style.textContent = `
        @keyframes __pm_slidein__ {
            from { opacity: 0; transform: translateY(-12px); }
            to   { opacity: 1; transform: translateY(0);     }
        }
    `;
    document.head.appendChild(style);

    banner.innerHTML = `
        <div style="font-weight:600; color:#d92d20; margin-bottom:5px; font-size:13px;">⚠ Sensitive Data Masked</div>
        <div style="color:#b54708; font-size:12px; font-weight:500;">Detected: ${matchedLabels.join(", ")}</div>
        <div style="color:#667085; font-size:11px; margin-top:5px;">Content was sanitized before pasting.</div>
    `;

    banner.addEventListener("click", () => banner.remove());
    document.body.appendChild(banner);
    setTimeout(() => banner?.remove(), 5000);
}

// ─── Whitelisted site banner (shown once per page load) ──────────────────────
function showWhitelistNotice() {
    document.getElementById("__paste-monitor-wl__")?.remove();

    const banner = document.createElement("div");
    banner.id = "__paste-monitor-wl__";
    banner.style.cssText = `
        position: fixed;
        top: 18px;
        right: 18px;
        z-index: 2147483647;
        background: #ffffff;
        color: #101828;
        border: 1px solid #a9efc5;
        border-left: 4px solid #027a48;
        border-radius: 8px;
        padding: 13px 16px;
        font-family: 'Inter', -apple-system, sans-serif;
        font-size: 13px;
        max-width: 320px;
        box-shadow: 0 4px 24px rgba(16,24,40,0.12);
        animation: __pm_slidein__ 0.22s ease;
        cursor: pointer;
    `;
    banner.innerHTML = `
        <div style="font-weight:600; color:#027a48; margin-bottom:5px;">✓ Paste Monitor Disabled</div>
        <div style="color:#475467; font-size:12px;">This site is whitelisted — all pastes are unrestricted.</div>
    `;
    banner.addEventListener("click", () => banner.remove());
    document.body.appendChild(banner);
    setTimeout(() => banner?.remove(), 3000);
}

// ─── Check whitelist then start listener ─────────────────────────────────────
const currentHostname = location.hostname;

chrome.storage.local.get(["whitelist"], (result) => {
    const whitelist = result.whitelist || [];
    const isWhitelisted = whitelist.includes(currentHostname);

    if (isWhitelisted) {
        // Show a one-time notice and do NOT attach the paste listener
        showWhitelistNotice();
        return;
    }

    // ── Paste listener (capture phase) ──────────────────────────────────────
    document.addEventListener("paste", (e) => {
        const text = e.clipboardData.getData("text");
        if (!text) return;

        const matched     = detectPatterns(text);
        const isSensitive = matched.length > 0;
        const finalText   = isSensitive ? maskSecrets(text) : text;

        if (isSensitive) {
            e.preventDefault();
            insertText(finalText);
            showAlert(matched);
            console.warn("[PasteMonitor] Sensitive data masked:", matched.join(", "));
        }

        chrome.runtime.sendMessage({
            type: "PASTE_EVENT",
            payload: {
                text:         finalText,
                originalText: isSensitive ? text : null,
                url:          location.href,
                masked:       isSensitive,
                detections:   matched,
                ts:           Date.now(),
            },
        });
    }, true);
});